Hi :3
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
//  __  __             _     _ _              _____            _ _           _____                    //
// |  \/  |           (_)   (_) |            |  __ \          (_) |         |_   _|                   //
// | \  / | __ _  __ _ _ ___ _| |_ __ _ ___  | |__) |__ _ _ __ _| |_ _   _    | |  ___ ___  _ __  ___ //
// | |\/| |/ _` |/ _` | / __| | __/ _` / __| |  _  // _` | '__| | __| | | |   | | / __/ _ \| '_ \/ __|//
// | |  | | (_| | (_| | \__ \ | || (_| \__ \ | | \ \ (_| | |  | | |_| |_| |  _| || (_| (_) | | | \__ \//
// |_|  |_|\__,_|\__, |_|___/_|\__\__,_|___/ |_|  \_\__,_|_|  |_|\__|\__, | |_____\___\___/|_| |_|___///
//                __/ |                                               __/ |                           //
//               |___/                                               |___/                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

/-------------------\
|HOW TO USE THE PACK|
\-------------------/

Step 1: Put the .zip in the .minecraft/resourcepacks folder
Step 2: Enable via the Minecraft ingame menu !
Step 3: Enjoy !!

/------------------------\
|FULL ICONS COMPATIBILITY|
\------------------------/

You will need to use the Icons pack UNDER my pack for it to work. Also if you don't use it Rarity Icons will display but some items will display some weird white squares
Link : Icons :

/---------------------------------\
|FULL ECLECTIC TROVE COMPATIBILITY|
\---------------------------------/

Not mendatory at all, but if you want the same displays that I have, here are the steps :
Step 1: Install Legendary Tooltips Mod and Item Borders Mod on any loader (forge, fabric...)
Step 3: Go in .minecraft/config and overite default legendarytooltips.toml and itemborders.toml with both my configs in the zip (note : if there is nothing to overite just put them there anyway)
Step 2: Install Eclectic Trove pack UNDER my pack and UNDER Icons if you have it.
Step 4: Launch the game and enable the pack
Links : Legendary Tooltips : | Item Borders Mod : | Eclectic Trove :

/----------------------------\
|MAKE YOUR OWN CUSTOM VERSION|
\----------------------------/

Here is all the things you should edit to make your custom version:

Change what item is in which rarity :
-> .minecraft/resourcepacks/Magisitas_Rarity_Icons-*.*.*-*.*.*\assets\minecraft\lang\en_us.json
---> Moving items from categories has NO EFFECT, you need to change the little text before the display items. 
---> You can change the text color and which Icon it's using. 
---> By default it will auto update what Legendary Tooltip it's using if you change the rarity to another one !

Change the Rarity Icons Sprites :
-> .minecraft/resourcepacks/Magisitas_Rarity_Icons-*.*.*-*.*.*\assets\minecraft\textures\custom\labels
---> DO NOT DELETE OR ADD ANY FILE, THIS WILL BREAK THE PACK AND MAKE YOUR GAME CRASH
---> You can only edit the current textures.
---> If you really want to have more rarities without editing the current ones, ask me on Discord it's very hard.

Change the way the item tooltips and item slot glow look :
-> .minecraft/config/legendarytooltips.toml and itemborders.toml

Change the tooltip border sprites :
-> .minecraft/resourcepacks/EclecticTrove-*.*.*-*.*.*\assets\legendarytooltips\textures\gui\tooltip-borders.png

/-------\
|SUPPORT|
\-------/

If you need any help, please contact me on DISCORD : @magisitas

Have fun :3