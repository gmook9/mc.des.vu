This resource pack aims to both combine my style of experience bottles with keyschain's style of bottles. Credit to keyschain for the regular bottle style and the splash potion bottle style.

Full credit to keyschain for all the modeling in this pack, I only copied and edited their files to apply to my retexture.

Link to keyschain Alternate 3D Potions resource pack:
https://www.curseforge.com/minecraft/texture-packs/alternate-3d-potions